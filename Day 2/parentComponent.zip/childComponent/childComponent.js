import { LightningElement, api } from 'lwc';

export default class ChildComponent extends LightningElement {

    @api recordId;

    sendMessage() {
        const event = new CustomEvent('message', {
            detail: 'Hello Parent!'
        });

        this.dispatchEvent(event);
    }

}